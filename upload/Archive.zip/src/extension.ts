import * as vscode from "vscode";
import * as crypto from "crypto";
import * as path from "path";

/**
 * A curated palette of visually distinct, pleasant colors.
 * Each entry is used as the accent for a workspace window.
 */
const COLOR_PALETTE = [
  "#E06C75", // soft red
  "#E5C07B", // gold
  "#61AFEF", // sky blue
  "#C678DD", // purple
  "#56B6C2", // teal
  "#98C379", // green
  "#D19A66", // orange
  "#BE5046", // rust
  "#7EC8E3", // light blue
  "#C9A0DC", // lavender
  "#F0E68C", // khaki
  "#FF8C69", // salmon
  "#87CEEB", // sky
  "#DDA0DD", // plum
  "#20B2AA", // light sea green
  "#F4A460", // sandy brown
  "#8FBC8F", // dark sea green
  "#CD853F", // peru
  "#6495ED", // cornflower
  "#DB7093", // pale violet red
];

/**
 * Derive a deterministic palette index from the workspace folder path.
 * Same folder → same color every time.
 */
function colorIndexForPath(folderPath: string): number {
  const hash = crypto.createHash("sha256").update(folderPath).digest("hex");
  const num = parseInt(hash.substring(0, 8), 16);
  return num % COLOR_PALETTE.length;
}

/**
 * Darken a hex color by a given factor (0–1, where 0 = black).
 */
function darken(hex: string, factor: number): string {
  const r = Math.round(parseInt(hex.slice(1, 3), 16) * factor);
  const g = Math.round(parseInt(hex.slice(3, 5), 16) * factor);
  const b = Math.round(parseInt(hex.slice(5, 7), 16) * factor);
  return `#${r.toString(16).padStart(2, "0")}${g
    .toString(16)
    .padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
}

/**
 * Choose black or white foreground depending on background luminance.
 */
function contrastForeground(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.55 ? "#000000" : "#ffffff";
}

/**
 * Apply the color customizations to the current workspace settings.
 */
async function applyColor(color: string): Promise<void> {
  const fg = contrastForeground(color);
  const borderColor = color;
  const statusBg = darken(color, 0.7);
  const statusFg = contrastForeground(statusBg);

  const config = vscode.workspace.getConfiguration("workbench");
  const customizations: Record<string, string> = {
    // Window border
    "window.activeBorder": borderColor,
    "window.inactiveBorder": darken(borderColor, 0.5),

    // Status bar (footer)
    "statusBar.background": statusBg,
    "statusBar.foreground": statusFg,
    "statusBar.debuggingBackground": darken(color, 0.55),
    "statusBar.debuggingForeground": "#ffffff",
    "statusBar.noFolderBackground": darken(color, 0.4),
    "statusBar.noFolderForeground": "#ffffff",

    // Title bar (optional, reinforces the color identity)
    "titleBar.activeBackground": color,
    "titleBar.activeForeground": fg,
    "titleBar.inactiveBackground": darken(color, 0.6),
    "titleBar.inactiveForeground": darken(fg, 0.7),

    // Activity bar accent
    "activityBarBadge.background": color,
    "activityBarBadge.foreground": fg,
  };

  await config.update(
    "colorCustomizations",
    customizations,
    vscode.ConfigurationTarget.Workspace
  );
}

/**
 * Remove workspace color customizations.
 */
async function clearColor(): Promise<void> {
  const config = vscode.workspace.getConfiguration("workbench");
  await config.update(
    "colorCustomizations",
    undefined,
    vscode.ConfigurationTarget.Workspace
  );
}

/**
 * Resolve the color for the current workspace by checking (in priority order):
 * 1. workspaceColors.color  — direct hex override (workspace or user settings)
 * 2. workspaceColors.colorMap — folder-name or full-path mapping (user settings)
 * 3. Auto-assigned color from the palette based on folder path hash
 */
function resolveColor(folderPath: string): string {
  const config = vscode.workspace.getConfiguration("workspaceColors");

  // Priority 1: direct override
  const directColor = config.get<string>("color", "").trim();
  if (directColor && /^#[0-9a-fA-F]{6}$/.test(directColor)) {
    return directColor;
  }

  // Priority 2: colorMap lookup (try full path first, then folder name)
  const colorMap = config.get<Record<string, string>>("colorMap", {});
  const folderName = path.basename(folderPath);

  if (colorMap[folderPath] && /^#[0-9a-fA-F]{6}$/.test(colorMap[folderPath])) {
    return colorMap[folderPath];
  }
  if (colorMap[folderName] && /^#[0-9a-fA-F]{6}$/.test(colorMap[folderName])) {
    return colorMap[folderName];
  }

  // Priority 3: auto-assign from palette
  const idx = colorIndexForPath(folderPath);
  return COLOR_PALETTE[idx];
}

/**
 * Apply color for the current workspace using the resolved settings.
 */
async function applyResolvedColor(): Promise<void> {
  const folders = vscode.workspace.workspaceFolders;
  if (!folders || folders.length === 0) {
    return;
  }

  const config = vscode.workspace.getConfiguration("workspaceColors");
  const enabled = config.get<boolean>("enabled", true);
  if (!enabled) {
    await clearColor();
    return;
  }

  const folderPath = folders[0].uri.fsPath;
  const color = resolveColor(folderPath);
  await applyColor(color);

  const name = path.basename(folderPath);
  vscode.window.setStatusBarMessage(
    `Workspace color set for "${name}" → ${color}`,
    3000
  );
}

// ── Extension lifecycle ────────────────────────────────────────────

export function activate(context: vscode.ExtensionContext) {
  // Apply on startup
  applyResolvedColor();

  // Re-apply when settings change
  const configWatcher = vscode.workspace.onDidChangeConfiguration((e) => {
    if (e.affectsConfiguration("workspaceColors")) {
      applyResolvedColor();
    }
  });

  // Re-roll: pick a random color regardless of the hash
  const rerollCmd = vscode.commands.registerCommand(
    "workspaceColors.reroll",
    async () => {
      const idx = Math.floor(Math.random() * COLOR_PALETTE.length);
      await applyColor(COLOR_PALETTE[idx]);
      vscode.window.showInformationMessage(
        `Workspace color changed to ${COLOR_PALETTE[idx]}`
      );
    }
  );

  // Clear: remove all workspace color customizations
  const clearCmd = vscode.commands.registerCommand(
    "workspaceColors.clear",
    async () => {
      await clearColor();
      vscode.window.showInformationMessage("Workspace color cleared.");
    }
  );

  context.subscriptions.push(configWatcher, rerollCmd, clearCmd);
}

export function deactivate() {}
