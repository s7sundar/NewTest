# Workspace Colors

A VS Code extension that **automatically assigns a unique color** to each workspace/folder window. Every time you open a different project, the window gets a distinct **border**, **status bar**, and **title bar** color — making it easy to tell windows apart at a glance.

## Features

- **Deterministic colors** — the same folder always gets the same color (based on its path).
- Colors the **window border**, **status bar (footer)**, **title bar**, and **activity bar badge**.
- 20-color curated palette of visually distinct, pleasant hues.
- Two commands available from the Command Palette:
  - `Workspace Colors: Re-roll Color` — pick a random color for the current window.
  - `Workspace Colors: Clear Color` — remove all workspace color customizations.

## Getting Started

```bash
npm install
npm run compile
```

Then press **F5** in VS Code to launch an Extension Development Host and test it.

## How It Works

1. On activation (after startup), the extension reads the first workspace folder path.
2. It hashes the path to deterministically pick a color from the palette.
3. It writes `workbench.colorCustomizations` into the **workspace** settings (`.vscode/settings.json`).
4. Each new folder/project you open gets its own unique color.
